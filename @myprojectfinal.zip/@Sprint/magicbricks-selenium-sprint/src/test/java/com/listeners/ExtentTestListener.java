package com.listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.setup.BaseSteps;
import com.utils.ExtentReportManager;
import com.utils.ScreenShots;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.ITestContext;

public class ExtentTestListener implements ITestListener {

	@Override
	public void onStart(ITestContext context) {
		ExtentReportManager.initializeReport();
		System.out.println("=== Test Suite Started: " + context.getName() + " ===");
	}

	@Override
	public void onTestStart(ITestResult result) {
		String testName = result.getMethod().getMethodName();
		String description = result.getMethod().getDescription();

		ExtentReportManager.createTest(testName, description != null ? description : "No description provided");
		ExtentReportManager.getTest().log(Status.INFO, "Test Started: " + testName);

		System.out.println("Started Test: " + testName);
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		String testName = result.getMethod().getMethodName();

		ExtentReportManager.getTest().log(Status.PASS,
				MarkupHelper.createLabel("Test PASSED: " + testName, ExtentColor.GREEN));
		
		// Capture screenshot on failure
				try {
					if (BaseSteps.getDriver() != null) {
						String screenshotPath = ScreenShots.captureScreenshot(BaseSteps.getDriver(), testName);
						if (screenshotPath != null) {
							ExtentReportManager.getTest().addScreenCaptureFromPath(screenshotPath, "Failure Screenshot");
						}
					}
				} catch (Exception e) {
					ExtentReportManager.getTest().log(Status.WARNING, "Could not capture screenshot: " + e.getMessage());
				}

		// Log execution time
		long executionTime = result.getEndMillis() - result.getStartMillis();
		ExtentReportManager.getTest().log(Status.INFO, "Execution Time: " + executionTime + " ms");

		System.out.println("Test PASSED: " + testName);
		ExtentReportManager.endTest();
	}

	@Override
	public void onTestFailure(ITestResult result) {
		String testName = result.getMethod().getMethodName();

		ExtentReportManager.getTest().log(Status.FAIL,
				MarkupHelper.createLabel("Test FAILED: " + testName, ExtentColor.RED));

		// Log failure reason
		String failureReason = result.getThrowable().getMessage();
		ExtentReportManager.getTest().log(Status.FAIL, "Failure Reason: " + failureReason);

		// Capture screenshot on failure
		try {
			if (BaseSteps.getDriver() != null) {
				String screenshotPath = ScreenShots.captureScreenshot(BaseSteps.getDriver(), testName);
				if (screenshotPath != null) {
					ExtentReportManager.getTest().addScreenCaptureFromPath(screenshotPath, "Failure Screenshot");
				}
			}
		} catch (Exception e) {
			ExtentReportManager.getTest().log(Status.WARNING, "Could not capture screenshot: " + e.getMessage());
		}

		// Log stack trace
		ExtentReportManager.getTest().log(Status.FAIL, result.getThrowable());

		System.out.println("Test FAILED: " + testName);
		ExtentReportManager.endTest();
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		String testName = result.getMethod().getMethodName();

		ExtentReportManager.getTest().log(Status.SKIP,
				MarkupHelper.createLabel("Test SKIPPED: " + testName, ExtentColor.YELLOW));

		if (result.getThrowable() != null) {
			ExtentReportManager.getTest().log(Status.SKIP, result.getThrowable());
		}

		System.out.println("Test SKIPPED: " + testName);
		ExtentReportManager.endTest();
	}

	@Override
	public void onFinish(ITestContext context) {
		ExtentReportManager.flushReport();

		System.out.println("=== Test Suite Completed: " + context.getName() + " ===");
		System.out.println("Total Tests: " + context.getAllTestMethods().length);
		System.out.println("Passed: " + context.getPassedTests().size());
		System.out.println("Failed: " + context.getFailedTests().size());
		System.out.println("Skipped: " + context.getSkippedTests().size());

		String reportPath = System.getProperty("user.dir") + "/target/report/";
		System.out.println("ExtentReport generated at: " + reportPath);
	}
}