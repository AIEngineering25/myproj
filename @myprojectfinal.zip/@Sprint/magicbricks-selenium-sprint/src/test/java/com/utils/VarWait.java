package com.utils;

public class VarWait {
	public static void waitFor(int milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	public static void waitForSeconds(int seconds) {
		waitFor(seconds * 1000);
	}
}
