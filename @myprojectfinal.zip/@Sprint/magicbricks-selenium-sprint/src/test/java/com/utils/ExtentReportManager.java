package com.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExtentReportManager {
	private static ExtentReports extent;
	private static ThreadLocal<ExtentTest> test = new ThreadLocal<>();

	public static void initializeReport() {
		if (extent == null) {
			String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
			String reportPath = System.getProperty("user.dir") + "/target/reports/ExtentReport_" + timestamp + ".html";

			ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);

			// Configure the report
			sparkReporter.config().setDocumentTitle("MagicBricks Automation Test Report");
			sparkReporter.config().setReportName("Test Execution Report");
			sparkReporter.config().setTheme(Theme.DARK);
			sparkReporter.config().setTimeStampFormat("dd/MM/yyyy hh:mm:ss");

			extent = new ExtentReports();
			extent.attachReporter(sparkReporter);

			// System information
			extent.setSystemInfo("Operating System", System.getProperty("os.name"));
			extent.setSystemInfo("Java Version", System.getProperty("java.version"));
			extent.setSystemInfo("Browser", "Chrome");
			extent.setSystemInfo("Environment", "QA");
			extent.setSystemInfo("Tester", "Automation Team");
		}
	}

	public static void createTest(String testName, String description) {
		ExtentTest extentTest = extent.createTest(testName, description);
		test.set(extentTest);
	}

	public static ExtentTest getTest() {
		return test.get();
	}

	public static void flushReport() {
		if (extent != null) {
			extent.flush();
		}
	}

	public static void endTest() {
		test.remove();
	}
}