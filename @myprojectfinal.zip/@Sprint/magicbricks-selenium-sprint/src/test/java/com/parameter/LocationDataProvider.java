package com.parameter;

import java.io.IOException;

import org.testng.annotations.DataProvider;

public class LocationDataProvider {
	@DataProvider(name = "LocationData", parallel = true)
	public Object[][] locationDataProvider() throws IOException {
		return ExcelReader.readData();
	}
}
