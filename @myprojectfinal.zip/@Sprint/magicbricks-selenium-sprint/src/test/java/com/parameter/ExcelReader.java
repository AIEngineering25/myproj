package com.parameter;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	public final static String path = "C:\\@Utkarsh\\Technical Sessions\\@Sprint\\magicbricks-selenium-sprint\\src\\test\\resource\\ExcelData\\LocationData.xlsx";

	public static String[][] readData() throws IOException {
		File file = new File(path);
		if (!file.exists()) {
			throw new IOException("Excel file not found at path: " + path);
		}

		try (XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(file))) {
			XSSFSheet sheet = workbook.getSheetAt(0);
			int rowCount = sheet.getPhysicalNumberOfRows();

			if (rowCount < 1) {
				throw new IOException("Excel sheet does not contain any data.");
			}

			// Check if first row is header or data
			XSSFRow firstRow = sheet.getRow(0);
			if (firstRow == null) {
				throw new IOException("First row is missing in Excel.");
			}

			// Determine if first row is header (contains "location" or similar text)
			boolean hasHeader = false;
			if (firstRow.getCell(0) != null) {
				String firstCellValue = firstRow.getCell(0).toString().toLowerCase();
				hasHeader = firstCellValue.contains("locations") || firstCellValue.contains("cities")
						|| firstCellValue.contains("places");
			}

			int dataStartRow = hasHeader ? 1 : 0;
			int dataRowCount = hasHeader ? rowCount - 1 : rowCount;

			if (dataRowCount < 1) {
				throw new IOException("Excel sheet does not contain enough data rows.");
			}

			// We'll read only the first column (locations) but keep the 2D array structure
			// for compatibility
			String[][] info = new String[dataRowCount][1];

			for (int i = dataStartRow; i < rowCount; i++) {
				XSSFRow row = sheet.getRow(i);
				if (row == null)
					continue;

				// Read only the first column (location column)
				if (row.getCell(0) != null) {
					info[i - dataStartRow][0] = row.getCell(0).toString().trim();
				} else {
					info[i - dataStartRow][0] = "";
				}

				System.out.println("Row " + (i + 1) + ": Location = " + info[i - dataStartRow][0]);
			}

			return info;
		}
	}
}