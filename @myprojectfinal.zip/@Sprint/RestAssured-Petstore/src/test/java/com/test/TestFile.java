package com.test;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.baseSteps.RequestSteps;
import com.utils.ExtentManager;

import io.restassured.response.Response;

public class TestFile {

    ExtentReports extent;
    ExtentTest test;

    private RequestSteps petSteps;
    private final int TEST_PET_ID = 12345;
    private final String PET_NAME = "Buddy";

    @BeforeClass
    public void setUp() {
        System.out.println("=== Setting up Petstore API Tests ===");
        petSteps = new RequestSteps();
        extent = ExtentManager.getInstance(); // Initialize ExtentReports
    }

    @BeforeMethod
    public void startTest(Method method) {
        String methodName = method.getName();
        test = extent.createTest(methodName);
        test.info("Starting test: " + methodName);
    }

    @Test(priority = 1, description = "Add a new pet to the store")
    public void testAddPet() {
        test.info("Adding a new pet...");
        Response response = petSteps.addPet(TEST_PET_ID, PET_NAME, "available");
        test.info("Received response with status code: " + response.getStatusCode());
        Assert.assertEquals(response.getStatusCode(), 200, "Failed to add pet");
        test.pass("Pet added successfully");
    }

    @Test(priority = 4, description = "Get pets by status")
    public void testGetPetsByStatus() {
        test.info("Getting pets by status...");
        Response response = petSteps.getPetsByStatus("sold");
        test.info("Received response with status code: " + response.getStatusCode());
        Assert.assertEquals(response.getStatusCode(), 200, "Failed to get pets by status");
        test.pass("Pets retrieved by status successfully");
    }

    @Test(groups = "smoke", description = "Smoke test for basic functionality")
    public void smokeTest() {
        test.info("Running smoke test...");
        int smokeTestId = 999;

        Response addResponse = petSteps.addPet(smokeTestId, "SmokeTestDog", "available");
        test.info("Add pet response status: " + addResponse.getStatusCode());
        Assert.assertEquals(addResponse.getStatusCode(), 200, "Smoke test - Failed to add pet");

        test.pass("Smoke test completed successfully!");
    }

    @AfterMethod
    public void afterEachTest(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            test.fail("Test failed: " + result.getThrowable());
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            test.pass("Test passed");
        } else if (result.getStatus() == ITestResult.SKIP) {
            test.skip("Test skipped: " + result.getThrowable());
        }
        System.out.println("Test method completed\n");
    }

    @AfterClass
    public void tearDown() {
        System.out.println("=== All tests completed ===");
        extent.flush(); // Write everything to the report
    }
}