package com.parameter;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyReader {
	private final Properties properties;

	public PropertyReader(String propertiesFile) {
		this.properties = new Properties();
		loadProperties(propertiesFile);
	}

	private void loadProperties(String propertiesFile) {
		try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propertiesFile)) {
			if (inputStream == null) {
				throw new IllegalArgumentException("Properties file not found: " + propertiesFile);
			}
			properties.load(inputStream);
		} catch (IOException e) {
			throw new RuntimeException("Error loading properties file: " + propertiesFile, e);
		}
	}

	public String getProperty(String key) {
		return properties.getProperty(key);
	}

	public String getProperty(String key, String defaultValue) {
		return properties.getProperty(key, defaultValue);
	}
}