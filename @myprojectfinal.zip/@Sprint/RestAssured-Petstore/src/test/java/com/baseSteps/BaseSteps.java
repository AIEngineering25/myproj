package com.baseSteps;

import com.parameter.PropertyReader;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseSteps {
	private static final String PROPERTIES_FILE = "PropertyFiles/Property.properties";
	protected RequestSpecification request;
	private final PropertyReader propertyReader;

	public BaseSteps() {
		this.propertyReader = new PropertyReader(PROPERTIES_FILE);
		setupBaseURI();
		this.request = RestAssured.given().header("Content-Type", "application/json").header("Accept",
				"application/json");
		setupAuthorization();
	}

	private void setupBaseURI() {
		String baseURL = propertyReader.getProperty("baseURL");
		if (baseURL == null || baseURL.isEmpty()) {
			throw new IllegalStateException("Base URL not found in properties file");
		}
		RestAssured.baseURI = baseURL;
	}

	private void setupAuthorization() {
		String authType = propertyReader.getProperty("auth.type");

		if (authType == null || "none".equalsIgnoreCase(authType)) {
			return; // No authentication required
		}

		switch (authType.toLowerCase()) {
		case "bearer":
			setupBearerAuth();
			break;
		case "basic":
			setupBasicAuth();
			break;
		case "apikey":
			setupApiKeyAuth();
			break;
		default:
			System.out.println("Warning: Unknown auth type: " + authType);
		}
	}

	private void setupBearerAuth() {
		String token = propertyReader.getProperty("auth.token");
		if (token != null && !token.isEmpty()) {
			this.request = this.request.header("Authorization", "Bearer " + token);
		} else {
			throw new IllegalStateException("Bearer token not found for bearer authentication");
		}
	}

	private void setupBasicAuth() {
		String username = propertyReader.getProperty("auth.username");
		String password = propertyReader.getProperty("auth.password");

		if (username != null && password != null && !username.isEmpty() && !password.isEmpty()) {
			this.request = this.request.auth().basic(username, password);
		} else {
			throw new IllegalStateException("Username/password not found for basic authentication");
		}
	}

	private void setupApiKeyAuth() {
		String apiKey = propertyReader.getProperty("auth.apikey");
		if (apiKey != null && !apiKey.isEmpty()) {
			String headerName = propertyReader.getProperty("auth.apikey.header");
			headerName = (headerName != null && !headerName.isEmpty()) ? headerName : "api_key";
			this.request = this.request.header(headerName, apiKey);
		} else {
			throw new IllegalStateException("API key not found for API key authentication");
		}
	}

	protected String getBasePath(String operation) {
		String path = propertyReader.getProperty("basepath" + operation);
		if (path == null) {
			throw new IllegalArgumentException("Base path not found for operation: " + operation);
		}
		return path;
	}

	protected Response executeRequest(String method, String endpoint, Object body) {
		switch (method.toUpperCase()) {
		case "POST":
			return body != null ? request.body(body).post(endpoint) : request.post(endpoint);
		case "GET":
			return request.get(endpoint);
		case "PUT":
			return body != null ? request.body(body).put(endpoint) : request.put(endpoint);
		case "DELETE":
			return request.delete(endpoint);
		default:
			throw new IllegalArgumentException("Unsupported HTTP method: " + method);
		}
	}

	protected void validateResponse(Response response, int expectedStatus) {
		response.then().statusCode(expectedStatus);
	}
}