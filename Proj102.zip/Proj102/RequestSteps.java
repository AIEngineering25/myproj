import com.parameters.PropertyReader;
import io.restassured.response.Response;
import org.json.JSONObject;

public class RequestSteps extends BaseSteps {
    
    // Pet data model as JSON
    private JSONObject createPetPayload(int id, String name, String status) {
        JSONObject pet = new JSONObject();
        pet.put("id", id);
        pet.put("name", name);
        pet.put("status", status);
        
        JSONObject category = new JSONObject();
        category.put("id", 1);
        category.put("name", "Dogs");
        pet.put("category", category);
        
        pet.put("photoUrls", new String[]{"string"});
        
        JSONObject tag = new JSONObject();
        tag.put("id", 1);
        tag.put("name", "tag1");
        pet.put("tags", new JSONObject[]{tag});
        
        return pet;
    }
    
    // POST - Add a new pet
    public Response addPet(int petId, String petName, String status) {
        JSONObject petData = createPetPayload(petId, petName, status);
        Response response = executeRequest("POST", getBasePath("Post"), petData.toString());
        validateResponse(response, 200);
        System.out.println("Pet added successfully: " + response.getBody().asString());
        return response;
    }
    
    // GET - Find pet by ID
    public Response getPetById(int petId) {
        String endpoint = getBasePath("Get") + petId;
        Response response = executeRequest("GET", endpoint, null);
        validateResponse(response, 200);
        System.out.println("Pet details: " + response.getBody().asString());
        return response;
    }
    
    // PUT - Update pet
    public Response updatePet(int petId, String petName, String status) {
        JSONObject petData = createPetPayload(petId, petName, status);
        Response response = executeRequest("PUT", getBasePath("Post"), petData.toString());
        validateResponse(response, 200);
        System.out.println("Pet updated successfully: " + response.getBody().asString());
        return response;
    }
    
    // DELETE - Delete pet
    public Response deletePet(int petId) {
        String endpoint = getBasePath("Delete") + petId;
        Response response = executeRequest("DELETE", endpoint, null);
        validateResponse(response, 200);
        System.out.println("Pet deleted successfully");
        return response;
    }
    
    // GET - Find pets by status
    public Response getPetsByStatus(String status) {
        String endpoint = getBasePath("Get") + "findByStatus?status=" + status;
        Response response = executeRequest("GET", endpoint, null);
        validateResponse(response, 200);
        System.out.println("Pets found with status " + status + ": " + response.getBody().asString());
        return response;
    }
}