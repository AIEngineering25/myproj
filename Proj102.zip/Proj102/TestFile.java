import io.restassured.response.Response;

public class TestFile {
    
    public static void main(String[] args) {
        RequestSteps petSteps = new RequestSteps();
        
        try {
            // Complete CRUD test flow
            System.out.println("=== Starting Petstore API Tests ===\n");
            
            // Test 1: Add a new pet
            System.out.println("1. Adding a new pet...");
            Response addResponse = petSteps.addPet(12345, "Buddy", "available");
            
            // Test 2: Get pet by ID
            System.out.println("\n2. Getting pet by ID...");
            Response getResponse = petSteps.getPetById(12345);
            
            // Test 3: Update pet status
            System.out.println("\n3. Updating pet status...");
            Response updateResponse = petSteps.updatePet(12345, "Buddy", "sold");
            
            // Test 4: Get pets by status
            System.out.println("\n4. Getting pets by status...");
            Response statusResponse = petSteps.getPetsByStatus("sold");
            
            // Test 5: Delete pet
            System.out.println("\n5. Deleting pet...");
            Response deleteResponse = petSteps.deletePet(12345);
            
            // Test 6: Verify pet is deleted (should return 404)
            System.out.println("\n6. Verifying pet deletion...");
            try {
                petSteps.getPetById(12345);
            } catch (Exception e) {
                System.out.println("Pet successfully deleted (404 expected)");
            }
            
            System.out.println("\n=== All tests completed successfully! ===");
            
        } catch (Exception e) {
            System.err.println("Test failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // Helper method for running individual test scenarios
    public static void runSmokeTest() {
        RequestSteps steps = new RequestSteps();
        System.out.println("Running smoke test...");
        steps.addPet(999, "TestDog", "available");
        steps.getPetById(999);
        steps.deletePet(999);
        System.out.println("Smoke test completed!");
    }
}
