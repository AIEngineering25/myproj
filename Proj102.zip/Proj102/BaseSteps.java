import com.parameters.PropertyReader;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.*;

public class BaseSteps {
    private static final String PROPERTIES_PATH = "Property.properties";
    protected RequestSpecification request;
    
    public BaseSteps() {
        setupBaseURI();
        this.request = given()
            .header("Content-Type", "application/json")
            .header("Accept", "application/json");
    }
    
    private void setupBaseURI() {
        RestAssured.baseURI = PropertyReader.getProperty(PROPERTIES_PATH, "baseURL");
    }
    
    protected String getBasePath(String operation) {
        return PropertyReader.getProperty(PROPERTIES_PATH, "basepath" + operation);
    }
    
    protected Response executeRequest(String method, String endpoint, Object body) {
        switch(method.toUpperCase()) {
            case "POST": return body != null ? request.body(body).post(endpoint) : request.post(endpoint);
            case "GET": return request.get(endpoint);
            case "PUT": return body != null ? request.body(body).put(endpoint) : request.put(endpoint);
            case "DELETE": return request.delete(endpoint);
            default: throw new IllegalArgumentException("Unsupported HTTP method: " + method);
        }
    }
    
    protected void validateResponse(Response response, int expectedStatus) {
        response.then().statusCode(expectedStatus);
    }
}
