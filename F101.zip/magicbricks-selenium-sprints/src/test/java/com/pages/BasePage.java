package com.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {
	protected WebDriver driver;
	protected WebDriverWait wait;

	public BasePage(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		PageFactory.initElements(driver, this);
	}

	// This class can only be extended by ByPage.java
	// Protected constructor ensures controlled inheritance
	protected BasePage() {
		// Default constructor for inheritance
	}

	// Common methods for all pages
	public String getCurrentUrl() {
		return driver.getCurrentUrl();
	}

	public String getPageTitle() {
		return driver.getTitle();
	}

	public boolean isPageLoaded() {
		return driver.getTitle() != null && !driver.getTitle().isEmpty();
	}

}
