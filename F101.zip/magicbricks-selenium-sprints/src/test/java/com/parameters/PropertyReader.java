package com.parameters;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyReader 
{
	public static String getProperty(String path, String key)
	{
		try 
		{
			FileInputStream file = new FileInputStream(path);
			Properties prop = new Properties();
			prop.load(file);
			return prop.getProperty(key);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "";
		}
	}
}
