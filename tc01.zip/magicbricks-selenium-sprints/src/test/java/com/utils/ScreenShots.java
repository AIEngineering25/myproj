package com.utils;

public class ScreenShots {

}
