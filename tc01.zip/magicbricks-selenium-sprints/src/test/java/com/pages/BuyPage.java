package com.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;
import java.util.Set;

public class BuyPage extends BasePage {
	private WebDriverWait wait;
	private Actions actions;

	public BuyPage(WebDriver driver) {
		super(driver);
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		this.actions = new Actions(driver);
		PageFactory.initElements(driver, this);
	}

	// Homepage Elements
	@FindBy(xpath = "//a[contains(text(),'Buy') or @title='Buy' or contains(@href,'buy')]")
	private WebElement buyTab;

	@FindBy(xpath = "//div[@class='drop-heading' and contains(text(),'Popular Choices')]")
	private WebElement popularChoicesHeading;

	@FindBy(xpath = "//div[@class='drop-call']//ul[@class='drop-links']//a[contains(text(),'Ready to Move')]")
	private WebElement readyToMoveLink;

	@FindBy(xpath = "//ul[@class='drop-links']//li//a[contains(text(),'Ready to Move') or contains(text(),'Ready To Move')]")
	private WebElement readyToMoveLinkAlt;

	// Ready To Move Page Elements
	@FindBy(xpath = "//h1[contains(text(),'Ready to Move') or contains(text(),'Ready To Move')]")
	private WebElement readyToMovePageHeading;

	@FindBy(xpath = "//div[@class='search-filter'] | //div[contains(@class,'filter')] | //form[contains(@class,'search')]")
	private WebElement searchFilterSection;

	@FindBy(xpath = "//div[contains(@class,'property-list')] | //div[contains(@class,'listing')] | //div[contains(@class,'results')]")
	private WebElement propertyListSection;

	public void navigateToMagicBricks() {
		driver.get("https://www.magicbricks.com");
		wait.until(ExpectedConditions.elementToBeClickable(buyTab));

		// Add delay to ensure page is fully loaded
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	public void hoverOnBuyTab() {
		wait.until(ExpectedConditions.visibilityOf(buyTab));
		actions.moveToElement(buyTab).perform();

		// Add delay to allow dropdown to appear
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	public void waitForPopularChoicesDropdown() {
		try {
			wait.until(ExpectedConditions.visibilityOf(popularChoicesHeading));
		} catch (Exception e) {
			System.out.println("Popular Choices heading not found with primary locator");
			wait.until(ExpectedConditions
					.presenceOfElementLocated(org.openqa.selenium.By.xpath("//div[@class='drop-call']")));
		}
	}

	public void clickReadyToMoveLink() {
		WebElement linkToClick = null;

		try {
			linkToClick = wait.until(ExpectedConditions.elementToBeClickable(readyToMoveLink));
		} catch (Exception e) {
			try {
				linkToClick = wait.until(ExpectedConditions.elementToBeClickable(readyToMoveLinkAlt));
			} catch (Exception e2) {
				linkToClick = wait.until(ExpectedConditions.elementToBeClickable(
						org.openqa.selenium.By.xpath("//a[contains(text(),'Ready') and contains(@target,'_blank')]")));
			}
		}

		if (linkToClick != null) {
			String originalWindow = driver.getWindowHandle();
			linkToClick.click();

			try {
				wait.until(ExpectedConditions.numberOfWindowsToBe(2));
			} catch (Exception e) {
				System.out.println("New tab may not have opened as expected");
			}
		} else {
			throw new RuntimeException("Ready to Move link not found");
		}
	}

	// Navigation Flow Method
	public boolean navigateToReadyToMovePage() {
		try {
			System.out.println("Step 1: Navigating to MagicBricks homepage...");
			navigateToMagicBricks();

			System.out.println("Step 2: Hovering on Buy tab...");
			hoverOnBuyTab();

			System.out.println("Step 3: Waiting for Popular Choices dropdown...");
			waitForPopularChoicesDropdown();

			System.out.println("Step 4: Clicking Ready to Move link...");
			clickReadyToMoveLink();

			System.out.println("Step 5: Switching to Ready to Move page...");
			switchToNewTab();

			return true;
		} catch (Exception e) {
			System.err.println("Navigation failed: " + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	// Verification Methods
	public boolean verifyNewTabOpened() {
		try {
			Set<String> windowHandles = driver.getWindowHandles();
			return windowHandles.size() > 1;
		} catch (Exception e) {
			return false;
		}
	}

	public void switchToNewTab() {
		Set<String> windowHandles = driver.getWindowHandles();
		for (String windowHandle : windowHandles) {
			if (!windowHandle.equals(driver.getWindowHandle())) {
				driver.switchTo().window(windowHandle);
				break;
			}
		}
	}

	public boolean verifyUrlContainsReadyToMove() {
		String currentUrl = getCurrentUrl().toLowerCase();
		return currentUrl.contains("ready") || currentUrl.contains("move") || currentUrl.contains("rtm")
				|| currentUrl.contains("buy");
	}

	public boolean verifyPageIsLoaded() {
		try {
			// Check if page title is loaded
			boolean titleLoaded = getPageTitle() != null && !getPageTitle().isEmpty();

			// Check if page is completely loaded using JavaScript
			JavascriptExecutor js = (JavascriptExecutor) driver;
			String readyState = js.executeScript("return document.readyState").toString();
			boolean documentReady = "complete".equals(readyState);

			// Wait for any of the expected page elements to be present
			boolean pageElementsPresent = false;
			try {
				// Try to find any characteristic element of Ready to Move page
				wait.until(ExpectedConditions.or(
						ExpectedConditions.presenceOfElementLocated(
								org.openqa.selenium.By.xpath("//h1[contains(text(),'Ready')]")),
						ExpectedConditions.presenceOfElementLocated(
								org.openqa.selenium.By.xpath("//div[contains(@class,'search')]")),
						ExpectedConditions.presenceOfElementLocated(
								org.openqa.selenium.By.xpath("//div[contains(@class,'filter')]")),
						ExpectedConditions.presenceOfElementLocated(
								org.openqa.selenium.By.xpath("//div[contains(@class,'property')]"))));
				pageElementsPresent = true;
			} catch (Exception e) {
				// If specific elements not found, check for general page structure
				try {
					wait.until(ExpectedConditions.presenceOfElementLocated(org.openqa.selenium.By.xpath("//body")));
					pageElementsPresent = true;
				} catch (Exception e2) {
					pageElementsPresent = false;
				}
			}

			System.out.println("Page Load Verification:");
			System.out.println("- Title loaded: " + titleLoaded);
			System.out.println("- Document ready: " + documentReady);
			System.out.println("- Page elements present: " + pageElementsPresent);

			return titleLoaded && documentReady && pageElementsPresent;

		} catch (Exception e) {
			System.err.println("Page load verification failed: " + e.getMessage());
			return false;
		}
	}

	public boolean verifyBuyPageElements() {
		try {
			// Wait a bit for page to stabilize
			Thread.sleep(2000);

			// Check for common elements on Ready to Move/Buy pages
			boolean hasSearchElements = !driver.findElements(org.openqa.selenium.By
					.xpath("//input[@type='text'] | //select | //button[contains(text(),'Search')]")).isEmpty();

			boolean hasPropertyElements = !driver.findElements(org.openqa.selenium.By.xpath(
					"//div[contains(@class,'property')] | //div[contains(@class,'listing')] | //a[contains(@href,'property')]"))
					.isEmpty();

			boolean hasFilterElements = !driver.findElements(org.openqa.selenium.By
					.xpath("//div[contains(@class,'filter')] | //span[contains(text(),'Filter')]")).isEmpty();

			System.out.println("Buy Page Elements Verification:");
			System.out.println("- Search elements present: " + hasSearchElements);
			System.out.println("- Property elements present: " + hasPropertyElements);
			System.out.println("- Filter elements present: " + hasFilterElements);

			return hasSearchElements || hasPropertyElements || hasFilterElements;

		} catch (Exception e) {
			System.err.println("Buy page elements verification failed: " + e.getMessage());
			return false;
		}
	}

	// TC_BUY_001 Complete Test Method
	public boolean executeBuyPageNavigationTest() {
		try {
			// Step 1: Navigate to Ready to Move page
			boolean navigationSuccess = navigateToReadyToMovePage();
			if (!navigationSuccess) {
				System.err.println("TC_BUY_001 FAILED: Navigation to Ready to Move page failed");
				return false;
			}

			// Step 2: Verify URL contains ready to move related terms
			boolean urlVerification = verifyUrlContainsReadyToMove();
			if (!urlVerification) {
				System.err.println("TC_BUY_001 FAILED: URL does not contain Ready to Move related terms");
				System.out.println("Current URL: " + getCurrentUrl());
				return false;
			}

			// Step 3: Verify entire page is loaded
			boolean pageLoadVerification = verifyPageIsLoaded();
			if (!pageLoadVerification) {
				System.err.println("TC_BUY_001 FAILED: Page is not fully loaded");
				return false;
			}

			// Additional verification: Check for Buy page specific elements
			boolean buyPageElements = verifyBuyPageElements();

			System.out.println("TC_BUY_001 SUCCESS: All verifications passed");
			System.out.println("Final Results:");
			System.out.println("- Navigation: " + navigationSuccess);
			System.out.println("- URL Verification: " + urlVerification);
			System.out.println("- Page Load Verification: " + pageLoadVerification);
			System.out.println("- Buy Page Elements: " + buyPageElements);
			System.out.println("- Current URL: " + getCurrentUrl());
			System.out.println("- Page Title: " + getPageTitle());

			return true;

		} catch (Exception e) {
			System.err.println("TC_BUY_001 FAILED: Exception occurred - " + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	// Debug method
	public void debugPageElements() {
		try {
			System.out.println("=== DEBUG: Current Page Information ===");
			System.out.println("URL: " + getCurrentUrl());
			System.out.println("Title: " + getPageTitle());

			// Find all links on the page
			java.util.List<WebElement> allLinks = driver.findElements(org.openqa.selenium.By.tagName("a"));
			System.out.println("Total links found: " + allLinks.size());

			// Find all input elements
			java.util.List<WebElement> allInputs = driver.findElements(org.openqa.selenium.By.tagName("input"));
			System.out.println("Total input elements found: " + allInputs.size());

			// Find elements with 'property' in class name
			java.util.List<WebElement> propertyElements = driver
					.findElements(org.openqa.selenium.By.xpath("//*[contains(@class,'property')]"));
			System.out.println("Elements with 'property' in class: " + propertyElements.size());

		} catch (Exception e) {
			System.err.println("Debug failed: " + e.getMessage());
		}
	}
}