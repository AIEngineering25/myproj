package com.tests;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;

import com.pages.BuyPage;
import com.setup.BaseSteps;

public class MainTest {
	@BeforeClass
	public void setUpTest() {
		// Ensure driver is initialized
		BaseSteps.setUp();
	}

	@AfterClass
	public void tearDownTest() {
		// Clean up driver
		BaseSteps.tearDown();
	}

	@Test(priority = 1, description = "TC_BUY_001: Verify Buy page navigation and elements")
	public void testBuyPageNavigationAndVerification() {
		System.out.println("\n=== EXECUTING TC_BUY_001: Buy Page Navigation and Elements ===");
		System.out.println("Test Condition: User should be able to navigate to Buy page from homepage");
		System.out.println("Expected Result: Buy page loads successfully");

		// Initialize the page object
		BuyPage byPage = new BuyPage(BaseSteps.getDriver());

		// Execute the complete test flow
		boolean testResult = byPage.executeBuyPageNavigationTest();

		// Verify the test execution was successful
		Assert.assertTrue(testResult, "TC_BUY_001 FAILED: Buy page navigation and verification failed");

		// Additional assertions for specific requirements
		String currentUrl = byPage.getCurrentUrl();
		Assert.assertTrue(byPage.verifyUrlContainsReadyToMove(),
				"TC_BUY_001 FAILED: URL does not contain Ready to Move related terms. Current URL: " + currentUrl);

		Assert.assertTrue(byPage.verifyPageIsLoaded(), "TC_BUY_001 FAILED: Page is not fully loaded");

		System.out.println("TC_BUY_001 PASSED: All test steps completed successfully!");
		System.out.println("Final URL: " + currentUrl);
		System.out.println("Page Title: " + byPage.getPageTitle());
	}

	// Optional debug test to troubleshoot issues
	@Test(enabled = false, description = "Debug test to analyze page elements")
	public void debugPageAnalysis() {
		BuyPage byPage = new BuyPage(BaseSteps.getDriver());

		// Navigate to Ready to Move page
		boolean navigationSuccess = byPage.navigateToReadyToMovePage();

		if (navigationSuccess) {
			byPage.debugPageElements();
		} else {
			System.out.println("Navigation failed, cannot debug page elements");
		}
	}

	// Basic navigation test for troubleshooting
	@Test(enabled = false, description = "Simple navigation test")
	public void simpleNavigationTest() {
		BuyPage byPage = new BuyPage(BaseSteps.getDriver());
		byPage.navigateToMagicBricks();

		System.out.println("Homepage loaded:");
		System.out.println("URL: " + byPage.getCurrentUrl());
		System.out.println("Title: " + byPage.getPageTitle());

		Assert.assertTrue(byPage.getCurrentUrl().contains("magicbricks.com"), "Failed to load MagicBricks homepage");
	}

}
